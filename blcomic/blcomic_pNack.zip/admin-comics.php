<?php
// require 'config.php';  // 注释掉原来的配置
session_start();
// 专门为标签管理使用blmh_site数据库
$host = 'localhost';
$dbname = 'blmh_site';  // 漫画数据库
$username = 'blmh_site';
$password = '4BtsZWFSQJNHABRc';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

require 'functions.php';

// 管理员权限验证
if (!isset($_SESSION['admin_verified']) || $_SESSION['admin_verified'] !== true) {
    header('Location: admin-login.php');
    exit;
}

// 处理表单提交
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // 处理图片上传
        $cover_image = '';
        $thumbnail = '';
        $banner_image = '';
        
        // 上传封面图片
        if (isset($_FILES['cover_image']) && $_FILES['cover_image']['error'] === UPLOAD_ERR_OK) {
            $cover_image = uploadImage($_FILES['cover_image'], 'covers');
        }
        
        // 上传缩略图
        if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] === UPLOAD_ERR_OK) {
            $thumbnail = uploadImage($_FILES['thumbnail'], 'thumbnails');
        }
        
        // 上传横幅图片
        if (isset($_FILES['banner_image']) && $_FILES['banner_image']['error'] === UPLOAD_ERR_OK) {
            $banner_image = uploadImage($_FILES['banner_image'], 'banners');
        }
        
        // 修改插入漫画数据的部分
        $stmt = $pdo->prepare("
            INSERT INTO comics (title, status, episodes, description, cover_image, thumbnail, banner_image) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $_POST['title'],
            $_POST['status'],
            $_POST['episodes'] ?? '', // 使用空字符串作为默认值
            $_POST['description'] ?? '',
            $cover_image,
            $thumbnail,
            $banner_image
        ]);
        
        $comic_id = $pdo->lastInsertId();
        
        // 处理资源链接
        if (!empty($_POST['resource_urls'])) {
            foreach ($_POST['resource_urls'] as $index => $url) {
                if (!empty($url) && !empty($_POST['resource_types'][$index])) {
                    $platform = getPlatformFromUrl($url);
                    $type = $_POST['resource_types'][$index];
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO comic_resources (comic_id, type, platform, url, sort_order) 
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$comic_id, $type, $platform, $url, $index + 1]);
                }
            }
        }
        
        // 处理标签
        if (!empty($_POST['tags'])) {
            $tagIds = $_POST['tags'];
            foreach ($tagIds as $tagId) {
                $stmt = $pdo->prepare("INSERT INTO comic_tag_relations (comic_id, tag_id) VALUES (?, ?)");
                $stmt->execute([$comic_id, $tagId]);
            }
        }
        
        $message = "漫画添加成功！ID: " . $comic_id;
        
    } catch (Exception $e) {
        $message = "添加失败: " . $e->getMessage();
    }
}

// 获取分类和标签数据
try {
    $categories = $pdo->query("SELECT * FROM comic_categories")->fetchAll(PDO::FETCH_ASSOC);
    $tags = $pdo->query("SELECT * FROM comic_tags")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $categories = [];
    $tags = [];
}

?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加漫画 - 管理员后台</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .admin-container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .admin-header {
            background: linear-gradient(135deg, #FFA500, #FF8C00);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .admin-header h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .admin-nav {
            background: #f8f9fa;
            padding: 15px 30px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .admin-nav a {
            color: #495057;
            text-decoration: none;
            margin-right: 20px;
            padding: 8px 16px;
            border-radius: 5px;
            transition: all 0.3s;
        }
        
        .admin-nav a:hover, .admin-nav a.active {
            background: #007bff;
            color: white;
        }
        
        .admin-content {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #495057;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(0,123,255,0.1);
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        
        .image-upload {
            border: 2px dashed #dee2e6;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            transition: border-color 0.3s;
        }
        
        .image-upload:hover {
            border-color: #007bff;
        }
        
        .image-upload input {
            display: none;
        }
        
        .image-upload label {
            cursor: pointer;
            color: #6c757d;
            display: block;
        }
        
        .image-upload i {
            font-size: 48px;
            margin-bottom: 10px;
            color: #adb5bd;
        }
        
        .image-preview {
            margin-top: 15px;
            display: none;
        }
        
        .image-preview img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 5px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .resource-item {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
            align-items: center;
        }
        
        .resource-item select, .resource-item input {
            flex: 1;
        }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,123,255,0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-danger {
            background: #dc3545;
            color: white;
        }
        
        .btn-sm {
            padding: 8px 15px;
            font-size: 14px;
        }
        
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .tags-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        
        .tag-checkbox {
            display: none;
        }
        
        .tag-label {
            padding: 8px 16px;
            background: #e9ecef;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s;
            user-select: none;
        }
        
        .tag-checkbox:checked + .tag-label {
            background: #007bff;
            color: white;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .admin-content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-book"></i> 漫画管理系统</h1>
            <p>添加新的漫画作品</p>
        </div>
        
        <div class="admin-nav">
            <a href="admin-comics.php"><i class="fas fa-plus"></i> 添加漫画</a>
            <a href="admin-comics-list.php"><i class="fas fa-list"></i> 漫画列表</a>
            <a href="admin-tags.php"><i class="fas fa-tags"></i> 标签管理</a>
            <a href="index.php"><i class="fas fa-home"></i> 返回首页</a>
        </div>
        
        <div class="admin-content">
            <?php if ($message): ?>
                <div class="message <?php echo strpos($message, '成功') !== false ? 'success' : 'error'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <!-- 基本信息 -->
                <div class="form-group">
                    <label class="form-label">名称*</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <!-- 标签 -->
                <div class="form-group">
                    <label class="form-label">标签</label>
                    <div class="tags-container">
                        <?php foreach ($tags as $tag): ?>
                            <input type="checkbox" name="tags[]" value="<?php echo $tag['id']; ?>" 
                                   id="tag_<?php echo $tag['id']; ?>" class="tag-checkbox">
                            <label for="tag_<?php echo $tag['id']; ?>" class="tag-label" 
                                   style="background-color: <?php echo $tag['color']; ?>; color: <?php echo $tag['text_color']; ?>">
                                <?php echo htmlspecialchars($tag['name']); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="form-row">
                    
                    <div class="form-group">
                        <label class="form-label">状态 *</label>
                        <select name="status" class="form-control" required>
                            <option value="连载">连载中</option>
                            <option value="完结">完结</option>
                            <option value="暂停">暂停</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">集数信息</label>
                        <input type="text" name="episodes" class="form-control" placeholder="例如：1-10完结">
                    </div>
                </div>
                
                <!-- 图片上传 -->
                <div class="form-row">
                    
                    <div class="form-group">
                        <label class="form-label">缩略图</label>
                        <div class="image-upload">
                            <input type="file" name="thumbnail" id="thumbnail" accept="image/*">
                            <label for="thumbnail">
                                <i class="fas fa-image"></i>
                                <div>点击上传缩略图</div>
                                <small>建议尺寸：80x100px</small>
                            </label>
                            <div class="image-preview" id="thumbnail_preview"></div>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">横幅图片</label>
                    <div class="image-upload">
                        <input type="file" name="banner_image" id="banner_image" accept="image/*">
                        <label for="banner_image">
                            <i class="fas fa-image"></i>
                            <div>点击上传横幅图片</div>
                            <small>建议尺寸：1200x300px</small>
                        </label>
                        <div class="image-preview" id="banner_preview"></div>
                    </div>
                </div>
                
                <!-- 标签 -->
                <div class="form-group">
                    <label class="form-label">标签</label>
                    <div class="tags-container">
                        <?php foreach ($tags as $tag): ?>
                            <input type="checkbox" name="tags[]" value="<?php echo $tag['id']; ?>" 
                                   id="tag_<?php echo $tag['id']; ?>" class="tag-checkbox">
                            <label for="tag_<?php echo $tag['id']; ?>" class="tag-label" 
                                   style="background-color: <?php echo $tag['color']; ?>">
                                <?php echo htmlspecialchars($tag['name']); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- 简介 -->
                <div class="form-group">
                    <label class="form-label">漫画简介</label>
                    <textarea name="description" class="form-control" placeholder="请输入漫画的详细介绍..."></textarea>
                </div>
                
                <!-- 资源链接 -->
                <div class="form-group">
                    <label class="form-label">资源链接</label>
                    <div id="resources-container">
                        <div class="resource-item">
                            <select name="resource_types[]" class="form-control">
                                <option value="资源链接">资源链接</option>
                                <option value="提取码">提取码</option>
                            </select>
                            <input type="url" name="resource_urls[]" class="form-control" placeholder="资源链接">
                            <button type="button" class="btn btn-danger btn-sm" onclick="removeResource(this)">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <button type="button" class="btn btn-secondary" onclick="addResource()" style="margin-top: 10px;">
                        <i class="fas fa-plus"></i> 添加资源链接
                    </button>
                </div>
                
                <!-- 提交按钮 -->
                <div class="form-group" style="text-align: center; margin-top: 30px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> 添加漫画
                    </button>
                    <button type="reset" class="btn btn-secondary">
                        <i class="fas fa-redo"></i> 重置表单
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // 图片预览功能
        function setupImagePreview(inputId, previewId) {
            const input = document.getElementById(inputId);
            const preview = document.getElementById(previewId);
            
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        preview.innerHTML = `<img src="${e.target.result}" alt="预览">`;
                        preview.style.display = 'block';
                    };
                    reader.readAsDataURL(file);
                }
            });
        }
        
        // 初始化图片预览
        setupImagePreview('cover_image', 'cover_preview');
        setupImagePreview('thumbnail', 'thumbnail_preview');
        setupImagePreview('banner_image', 'banner_preview');
        
        // 资源链接管理
        function addResource() {
            const container = document.getElementById('resources-container');
            const newResource = document.createElement('div');
            newResource.className = 'resource-item';
            newResource.innerHTML = `
                <select name="resource_types[]" class="form-control">
                    <option value="资源链接">资源链接</option>
                    <option value="提取码">提取码</option>

                </select>
                <input type="url" name="resource_urls[]" class="form-control" placeholder="资源链接">
                <button type="button" class="btn btn-danger btn-sm" onclick="removeResource(this)">
                    <i class="fas fa-times"></i>
                </button>
            `;
            container.appendChild(newResource);
        }
        
        function removeResource(button) {
            const container = document.getElementById('resources-container');
            if (container.children.length > 1) {
                button.parentElement.remove();
            }
        }
        
        // 表单提交前验证
        document.querySelector('form').addEventListener('submit', function(e) {
            const title = this.querySelector('input[name="title"]').value.trim();
            if (!title) {
                e.preventDefault();
                alert('请输入漫画标题');
                return;
            }
            
            const category = this.querySelector('select[name="category_id"]').value;
            if (!category) {
                e.preventDefault();
                alert('请选择漫画分类');
                return;
            }
        });
    </script>
</body>
</html>