<?php
// require 'config.php';  // 注释掉原来的配置
session_start();
// 专门为标签管理使用blmh_site数据库
$host = 'localhost';
$dbname = 'blmh_site';  // 漫画数据库
$username = 'blmh_site';
$password = '4BtsZWFSQJNHABRc';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("数据库连接失败: " . $e->getMessage());
}

require 'functions.php';

// 管理员权限验证
if (!isset($_SESSION['admin_verified']) || $_SESSION['admin_verified'] !== true) {
    header('Location: admin-login.php');
    exit;
}

// 获取漫画列表
try {
    $stmt = $pdo->prepare("
        SELECT c.*, cat.name as category_name 
        FROM comics c 
        LEFT JOIN comic_categories cat ON c.category_id = cat.id 
        ORDER BY c.id DESC
    ");
    $stmt->execute();
    $comics = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $comics = [];
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>漫画列表 - 管理员后台</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* 复用之前的样式，添加表格样式 */
        .comics-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .comics-table th,
        .comics-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        
        .comics-table th {
            background: #f8f9fa;
            font-weight: 600;
        }
        
        .comic-cover {
            width: 40px;
            height: 50px;
            object-fit: cover;
            border-radius: 4px;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .status-ongoing {
            background: #e4f4ff;
            color: #3498db;
        }
        
        .status-completed {
            background: #ffe4e4;
            color: #e74c3c;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="admin-header">
            <h1><i class="fas fa-list"></i> 漫画列表</h1>
            <p>管理所有漫画作品</p>
        </div>
        
        <div class="admin-nav">
            <a href="admin-comics.php"><i class="fas fa-plus"></i> 添加漫画</a>
            <a href="admin-comics-list.php"><i class="fas fa-list"></i> 漫画列表</a>
            <a href="admin-tags.php"><i class="fas fa-tags"></i> 标签管理</a>
            <a href="index.php"><i class="fas fa-home"></i> 返回首页</a>
        </div>
        
        <div class="admin-content">
            <?php if (empty($comics)): ?>
                <div style="text-align: center; padding: 40px; color: #6c757d;">
                    <i class="fas fa-book-open" style="font-size: 48px; margin-bottom: 16px;"></i>
                    <div>暂无漫画数据</div>
                    <a href="admin-comics.php" class="btn btn-primary" style="margin-top: 20px;">
                        <i class="fas fa-plus"></i> 添加第一本漫画
                    </a>
                </div>
            <?php else: ?>
                <table class="comics-table">
                    <thead>
                        <tr>
                            <th>封面</th>
                            <th>标题</th>
                            <th>作者</th>
                            <th>状态</th>
                            <th>分类</th>
                            <th>浏览</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($comics as $comic): ?>
                        <tr>
                            <td>
                                <?php if (!empty($comic['thumbnail'])): ?>
                                    <img src="<?php echo htmlspecialchars($comic['thumbnail']); ?>" 
                                         alt="封面" class="comic-cover">
                                <?php else: ?>
                                    <div style="width:40px;height:50px;background:#f0f0f0;border-radius:4px;"></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($comic['title']); ?></strong>
                                <?php if (!empty($comic['episodes'])): ?>
                                    <br><small style="color:#666;"><?php echo htmlspecialchars($comic['episodes']); ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($comic['author'] ?? '-'); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo $comic['status'] === '连载中' ? 'ongoing' : 'completed'; ?>">
                                    <?php echo htmlspecialchars($comic['status']); ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($comic['category_name']); ?></td>
                            <td><?php echo number_format($comic['view_count']); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="comic-detail.php?id=<?php echo $comic['id']; ?>" 
                                       class="btn btn-primary btn-sm" target="_blank">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="admin-edit-comic.php?id=<?php echo $comic['id']; ?>" 
                                       class="btn btn-secondary btn-sm">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button class="btn btn-danger btn-sm" 
                                            onclick="deleteComic(<?php echo $comic['id']; ?>, '<?php echo htmlspecialchars($comic['title']); ?>')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function deleteComic(id, title) {
            if (confirm('确定要删除漫画《' + title + '》吗？此操作不可恢复！')) {
                // 这里可以添加AJAX删除功能
                alert('删除功能待实现 - 漫画ID: ' + id);
            }
        }
    </script>
</body>
</html>