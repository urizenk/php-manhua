<?php
session_start();
require 'config.php';
require 'functions.php';

// 用户验证
if (!isset($_SESSION['verified']) || $_SESSION['verified'] !== true) {
    header('Location: index.php');
    exit;
}

// 密码版本验证
try {
    $latest_password_id = null;
    if ($redis && $redis->exists('latest_password_id')) {
        $latest_password_id = $redis->get('latest_password_id');
    } else {
        $latest_password_id = getLatestPasswordIdFromDB($pdo);
        if ($redis) {
            $redis->setex('latest_password_id', 7200, $latest_password_id);
        }
    }
    
    if ($_SESSION['password_version'] != $latest_password_id) {
        session_unset();
        session_destroy();
        header('Location: index.php');
        exit;
    }
} catch (Exception $e) {
    error_log("密码版本验证失败: " . $e->getMessage());
}

// 获取漫画ID
$comic_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($comic_id <= 0) {
    die('漫画不存在');
}

// 检查管理员权限
$is_admin = isset($_SESSION['admin_verified']) && $_SESSION['admin_verified'] === true;

// 获取漫画详情
try {
    $stmt = $pdo->prepare("
        SELECT c.*, cat.name as category_name 
        FROM comics c 
        LEFT JOIN comic_categories cat ON c.category_id = cat.id 
        WHERE c.id = ?
    ");
    $stmt->execute([$comic_id]);
    $comic = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$comic) {
        die('漫画不存在');
    }
    
    // 获取标签
    $stmt = $pdo->prepare("
        SELECT t.name, t.color 
        FROM comic_tags t
        JOIN comic_tag_relations r ON t.id = r.tag_id
        WHERE r.comic_id = ?
    ");
    $stmt->execute([$comic_id]);
    $tags = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 获取资源链接
    $stmt = $pdo->prepare("
        SELECT type, url, platform 
        FROM comic_resources 
        WHERE comic_id = ? 
        ORDER BY sort_order
    ");
    $stmt->execute([$comic_id]);
    $resources = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 更新浏览次数
    $pdo->prepare("UPDATE comics SET view_count = view_count + 1 WHERE id = ?")->execute([$comic_id]);
    
} catch (PDOException $e) {
    die('数据加载失败: ' . $e->getMessage());
}

// 状态颜色映射
$statusColors = [
    '完结' => '#ffe4e4',
    '连载中' => '#e4f4ff',
    '暂停' => '#fff4e4'
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($comic['title']); ?> - 海の小窝</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Microsoft YaHei', sans-serif;
            background-color: #FFFFF0;
            color: #333;
            line-height: 1.6;
        }
        
        .banner {
            width: 100%;
            height: 280px;
            background: <?php echo !empty($comic['banner_image']) 
                ? "url('" . htmlspecialchars($comic['banner_image']) . "') center/cover" 
                : "linear-gradient(135deg, #FFD89B 0%, #FF9A9E 50%, #FF6B6B 100%)"; ?>;
            position: relative;
            overflow: hidden;
        }
        
        .banner-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 20px;
            background: linear-gradient(transparent, rgba(0,0,0,0.5));
            color: white;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
            background: white;
            min-height: calc(100vh - 280px);
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        
        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: #EC5800;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background 0.3s;
        }
        
        .back-btn:hover {
            background: #e69500;
        }
        
        .edit-btn {
            padding: 10px 20px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            display: none;
        }
        
        .edit-btn.show {
            display: inline-block;
        }
        
        .edit-btn:hover {
            background: #2980b9;
        }
        
        .comic-title {
            font-size: 42px;
            font-weight: bold;
            margin-bottom: 30px;
            color: #2c3e50;
            border-bottom: 3px solid #FFA500;
            padding-bottom: 10px;
        }
        
        .comic-content {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 40px;
            align-items: start;
        }
        
        .cover-section {
            text-align: center;
        }
        
        .cover-image {
            width: 100%;
            max-width: 280px;
            height: 400px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border: 5px solid white;
        }
        
        .cover-placeholder {
            width: 100%;
            max-width: 280px;
            height: 400px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .info-section {
            padding: 20px 0;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 25px;
            align-items: flex-start;
        }
        
        .info-label {
            width: 120px;
            font-size: 16px;
            color: #7f8c8d;
            font-weight: 500;
            padding-top: 8px;
            flex-shrink: 0;
        }
        
        .info-content {
            flex: 1;
            font-size: 16px;
            line-height: 1.8;
        }
        
        .status-badge {
            display: inline-block;
            padding: 8px 24px;
            border-radius: 5px;
            font-size: 15px;
            font-weight: 500;
            color: #d63031;
            background-color: <?php echo $statusColors[$comic['status']] ?? '#f0f0f0'; ?>;
        }
        
        .tags-container {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .tag {
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            color: white;
            cursor: default;
            transition: transform 0.2s;
            background-color: <?php echo $tag['color'] ?? '#3498db'; ?>;
        }
        
        .tag:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .description {
            line-height: 2;
            color: #555;
            font-size: 15px;
            white-space: pre-wrap;
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            border-left: 4px solid #FFA500;
        }
        
        .resource-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            transition: background 0.3s;
            border-radius: 8px;
        }
        
        .resource-item:hover {
            background: #f8f9fa;
        }
        
        .resource-item:last-child {
            border-bottom: none;
        }
        
        .resource-icon {
            margin-right: 15px;
            color: #95a5a6;
            font-size: 20px;
            width: 24px;
            text-align: center;
        }
        
        .resource-link {
            color: #3498db;
            text-decoration: none;
            font-size: 15px;
            word-break: break-all;
            transition: color 0.3s;
        }
        
        .resource-link:hover {
            color: #2980b9;
            text-decoration: underline;
        }
        
        .view-count {
            color: #999;
            font-size: 14px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            text-align: center;
        }
        
        .platform-badge {
            display: inline-block;
            padding: 2px 8px;
            background: #e74c3c;
            color: white;
            border-radius: 3px;
            font-size: 12px;
            margin-left: 8px;
        }
        
        @media (max-width: 768px) {
            .comic-content {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            
            .cover-section {
                text-align: center;
            }
            
            .cover-image, .cover-placeholder {
                max-width: 250px;
                height: 350px;
            }
            
            .comic-title {
                font-size: 32px;
            }
            
            .info-row {
                flex-direction: column;
                gap: 10px;
            }
            
            .info-label {
                width: 100%;
                padding-top: 0;
            }
        }
    </style>
</head>
<body>
    <div class="banner">
        <div class="banner-overlay">
            <div style="max-width: 1200px; margin: 0 auto;">
                <h2><?php echo htmlspecialchars($comic['category_name']); ?></h2>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="header-actions">
            <a href="javascript:history.back()" class="back-btn">
                <i class="fas fa-arrow-left"></i> 返回列表
            </a>
            <?php if ($is_admin): ?>
            <button class="edit-btn show" onclick="window.location.href='admin-edit-comic.php?id=<?php echo $comic_id; ?>'">
                <i class="fas fa-edit"></i> 编辑漫画
            </button>
            <?php endif; ?>
        </div>
        
        <h1 class="comic-title"><?php echo htmlspecialchars($comic['title']); ?></h1>
        
        <div class="comic-content">
            <!-- 封面图片区域 -->
            <div class="cover-section">
                <?php if (!empty($comic['cover_image'])): ?>
                    <img src="<?php echo htmlspecialchars($comic['cover_image']); ?>" 
                         alt="<?php echo htmlspecialchars($comic['title']); ?>" 
                         class="cover-image">
                <?php else: ?>
                    <div class="cover-placeholder">
                        <div>
                            <i class="fas fa-image" style="font-size: 48px; margin-bottom: 10px;"></i>
                            <div>暂无封面</div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- 漫画信息区域 -->
            <div class="info-section">
                <!-- 作者信息 -->
                <?php if (!empty($comic['author'])): ?>
                <div class="info-row">
                    <div class="info-label">作者</div>
                    <div class="info-content"><?php echo htmlspecialchars($comic['author']); ?></div>
                </div>
                <?php endif; ?>
                
                <!-- 状态 -->
                <div class="info-row">
                    <div class="info-label">状态</div>
                    <div class="info-content">
                        <span class="status-badge"><?php echo htmlspecialchars($comic['status']); ?></span>
                    </div>
                </div>
                
                <!-- 集数信息 -->
                <?php if (!empty($comic['episodes'])): ?>
                <div class="info-row">
                    <div class="info-label">集数</div>
                    <div class="info-content"><?php echo htmlspecialchars($comic['episodes']); ?></div>
                </div>
                <?php endif; ?>
                
                <!-- 标签 -->
                <?php if (!empty($tags)): ?>
                <div class="info-row">
                    <div class="info-label">标签</div>
                    <div class="info-content">
                        <div class="tags-container">
                            <?php foreach ($tags as $tag): ?>
                            <span class="tag" style="background-color: <?php echo htmlspecialchars($tag['color'] ?? '#3498db'); ?>">
                                <?php echo htmlspecialchars($tag['name']); ?>
                            </span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- 简介 -->
                <?php if (!empty($comic['description'])): ?>
                <div class="info-row">
                    <div class="info-label">简介</div>
                    <div class="info-content">
                        <div class="description"><?php echo htmlspecialchars($comic['description']); ?></div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- 资源链接 -->
                <?php if (!empty($resources)): ?>
                <div class="info-row">
                    <div class="info-label">资源链接</div>
                    <div class="info-content">
                        <?php foreach ($resources as $resource): ?>
                        <div class="resource-item">
                            <?php
                            $icon = 'fa-link';
                            if (strpos($resource['platform'], '百度') !== false) $icon = 'fa-cloud';
                            elseif (strpos($resource['platform'], '蓝奏') !== false) $icon = 'fa-download';
                            elseif (strpos($resource['platform'], 'Flowus') !== false) $icon = 'fa-file-alt';
                            ?>
                            <i class="fas <?php echo $icon; ?> resource-icon"></i>
                            <div style="flex: 1;">
                                <div style="font-size: 13px; color: #999; margin-bottom: 4px;">
                                    <?php echo htmlspecialchars($resource['type']); ?>
                                    <?php if (!empty($resource['platform'])): ?>
                                    <span class="platform-badge"><?php echo htmlspecialchars($resource['platform']); ?></span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php echo htmlspecialchars($resource['url']); ?>" 
                                   class="resource-link" 
                                   target="_blank"
                                   rel="noopener noreferrer">
                                    <?php echo htmlspecialchars($resource['url']); ?>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- 浏览统计 -->
                <div class="view-count">
                    <i class="fas fa-eye"></i> 浏览次数: <?php echo number_format($comic['view_count']); ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // 图片加载失败处理
        document.addEventListener('DOMContentLoaded', function() {
            const coverImage = document.querySelector('.cover-image');
            if (coverImage) {
                coverImage.onerror = function() {
                    this.style.display = 'none';
                    const placeholder = document.createElement('div');
                    placeholder.className = 'cover-placeholder';
                    placeholder.innerHTML = `
                        <div>
                            <i class="fas fa-image" style="font-size: 48px; margin-bottom: 10px;"></i>
                            <div>封面加载失败</div>
                        </div>
                    `;
                    this.parentNode.appendChild(placeholder);
                };
            }
        });
    </script>
</body>
</html>